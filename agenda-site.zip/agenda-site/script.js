const users = {
    "escola teste": "123Escola",
    "admin": "123Admin" // Adicionando um usuário admin
  };
  
  const agendamentos = [
    { recurso: "Biblioteca", data: "2024-11-15", horario: "10:00", nome: "Professor João", user: "escola teste" },
    // Outros agendamentos aqui
  ];
  
  function login(event) {
    event.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    
    if (users[username] === password) {
      document.getElementById("loginContainer").classList.add("hidden");
      document.getElementById("agendamentoContainer").classList.remove("hidden");
  
      if (username === "admin") {
        document.getElementById("adminAgendamentosContainer").classList.remove("hidden");
        mostrarAgendamentosAdmin();
      }
    } else {
      alert("Login ou senha incorretos!");
    }
  }
  
  function mostrarAgendamentosAdmin() {
    const agendamentosDiv = document.getElementById('agendamentosAdmin');
    agendamentosDiv.innerHTML = "";
    
    agendamentos.forEach((agendamento, index) => {
      const div = document.createElement("div");
      div.innerHTML = `<strong>${agendamento.nome}</strong> - ${agendamento.recurso} - ${agendamento.data} - ${agendamento.horario} 
                      <button onclick="excluirAgendamento(${index})">Excluir</button>`;
      agendamentosDiv.appendChild(div);
    });
  }
  
  function excluirAgendamento(index) {
    agendamentos.splice(index, 1); // Remove o agendamento do array
    mostrarFeedback("Agendamento excluído com sucesso!", "green");
    mostrarAgendamentosAdmin();
  }
  
  function nextStep(step) {
    if (!validaFormulario(step)) return; // Valida cada etapa
    document.getElementById(`step${step - 1}`).classList.add("hidden");
    document.getElementById(`step${step}`).classList.remove("hidden");
  }
  
  function validaFormulario(step) {
    if (step === 3) {
      const dataSelecionada = document.getElementById("data").value;
      if (new Date(dataSelecionada) < new Date()) {
        mostrarFeedback("Não foi possível adicionar este agendamento: Data Retroativa.", "red");
        return false;
      }
    }
    if (step === 4) {
      const horarioSelecionado = document.getElementById("horario").value;
      const dataSelecionada = document.getElementById("data").value;
      const recursoSelecionado = document.getElementById("recurso").value;
  
      const existeAgendamento = agendamentos.some(ag => ag.recurso === recursoSelecionado && ag.data === dataSelecionada && ag.horario === horarioSelecionado);
      
      if (existeAgendamento) {
        mostrarFeedback("Já possuem agendamentos para esta data/hora.", "red");
        return false;
      }
      if (new Date(`${dataSelecionada}T${horarioSelecionado}:00`) < new Date()) {
        mostrarFeedback("Não foi possível adicionar este agendamento: Horário Retroativo.", "red");
        return false;
      }
    }
    return true;
  }
  
  function submitAgendamento() {
    const nome = document.getElementById("nome").value;
    const recurso = document.getElementById("recurso").value;
    const data = document.getElementById("data").value;
    const horario = document.getElementById("horario").value;
  
    if (new Date(data) < new Date() || agendamentos.some(ag => ag.recurso === recurso && ag.data === data && ag.horario === horario)) {
      mostrarFeedback("Não foi possível adicionar este agendamento: Data ou Horário Retroativo.", "red");
      return;
    }
  
    agendamentos.push({ nome, recurso, data, horario, user: document.getElementById("username").value });
    mostrarFeedback("Agendamento realizado com sucesso!", "green");
    mostrarAgendamentos();
    document.getElementById("agendamentoContainer").classList.add("hidden");
    document.getElementById("confirmacaoContainer").classList.remove("hidden");
  }
  
  function mostrarFeedback(message, color) {
    const feedbackDiv = document.getElementById('feedback');
    feedbackDiv.innerHTML = message;
    feedbackDiv.style.color = color;
    feedbackDiv.classList.remove("hidden");
  
    // Esconder feedback após 2 segundos
    setTimeout(() => {
      feedbackDiv.classList.add("hidden");
    }, 2000);
  }
  
  function mostrarAgendamentos() {
    const recurso = document.getElementById("recurso").value;
    const data = document.getElementById("data").value;
    const agendamentosDiv = document.getElementById('agendamentos');
    
    // Limpeza dos agendamentos anteriores
    agendamentosDiv.innerHTML = "";
  
    // Simula carregamento de agendamentos para o recurso e data selecionados
    const agendamentosFiltrados = agendamentos.filter(ag => ag.recurso === recurso && ag.data === data);
    agendamentosFiltrados.forEach(agendamento => {
      const div = document.createElement("div");
      div.innerHTML = `<strong>${agendamento.nome}</strong> - ${agendamento.horario}`;
      agendamentosDiv.appendChild(div);
    });
  }
  
  // Função que remove agendamentos passados
  function removerAgendamentosPassados() {
    const hoje = new Date();
    agendamentos.forEach((agendamento, index) => {
      const dataAgendamento = new Date(agendamento.data);
      if (dataAgendamento < hoje) {
        agendamentos.splice(index, 1); // Remove os agendamentos passados
      }
    });
  }
  
  // Função para voltar à tela inicial
  function voltarTelaInicial() {
    // Oculta as etapas de agendamento
    document.getElementById("step1").classList.add("hidden");
    document.getElementById("step2").classList.add("hidden");
    document.getElementById("step3").classList.add("hidden");
    document.getElementById("step4").classList.add("hidden");
  
    // Exibe o painel de agendamentos
    document.getElementById("agendamentoContainer").classList.remove("hidden");
  
    // Limpa o feedback da tela de agendamento, se necessário
    const feedbackDiv = document.getElementById("feedback");
    feedbackDiv.innerHTML = "";
    feedbackDiv.classList.add("hidden");
  }
  
  // Chama a função para remover agendamentos passados diariamente
  setInterval(removerAgendamentosPassados, 86400000); // Chama uma vez por dia
  